# solitario


(Pendientes) 
Agregar comentarios y dar formato al codigo (ordenar)


Avisar cuando un movimiento es prohibido (pop up, cambiar puntero a una X, mensaje temporal en pantalla <p>) david

revisar los contadores (preguntar al prpf si es necesario crear el incrementar contador) - 